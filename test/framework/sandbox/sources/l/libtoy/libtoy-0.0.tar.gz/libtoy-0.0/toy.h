void toy_function();
