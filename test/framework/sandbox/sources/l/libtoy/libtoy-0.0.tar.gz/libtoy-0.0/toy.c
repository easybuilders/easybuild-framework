#include <stdio.h>

void toy_function() {
    printf("Hello from a toy function!\n");
}
