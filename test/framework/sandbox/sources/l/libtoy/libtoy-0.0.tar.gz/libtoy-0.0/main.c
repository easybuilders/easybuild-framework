#include <toy.h>

int main(int argc, char* argv[]){
    toy_function();
    return 0;
}
