testrepository
==============

This repository will be used in the unittests for easybuild-framework/tools/github.py's github api.